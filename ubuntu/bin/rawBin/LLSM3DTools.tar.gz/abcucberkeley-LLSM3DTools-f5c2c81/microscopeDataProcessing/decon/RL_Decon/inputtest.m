function inputtest(input1)

if ischar(input1)
    disp 1
end

%disp(input1)
end