$HOME/matlab/inputtest 1
